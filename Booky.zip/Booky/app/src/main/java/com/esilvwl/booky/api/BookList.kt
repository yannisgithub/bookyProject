package com.esilvwl.booky.api

import com.google.gson.annotations.SerializedName

class BookList (
    val items: List<Book>
)
class Book (
    val volumeInfo: BookInfo,
    val saleInfo: SaleInfo
)

class BookInfo (
    val title: String,
    val authors: List<String>,
    val publishedDate: String,
    val description: String,
    val imageLinks: imageLinks
)

class imageLinks(
    val smallThumbnail: String,
    val thumbnail: String
)

class SaleInfo(
    val retailPrice: Price
)

class Price(
    val amount: String,
    val currencyCode: String
)
