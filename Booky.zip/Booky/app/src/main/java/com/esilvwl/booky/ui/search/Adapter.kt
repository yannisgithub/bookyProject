package com.esilvwl.booky.ui.search

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.esilvwl.booky.R
import com.esilvwl.booky.api.BookList


class Adapter(context: Context, bookList: BookList?) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var bookList = bookList
    var context = context
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

        val view = LayoutInflater.from(parent.context).inflate(R.layout.viewholder_search, parent, false)
        return SearchViewHolder(view)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is SearchViewHolder -> {
                holder.title.text = bookList!!.items[position].volumeInfo.title;
                holder.author.text = bookList!!.items[position].volumeInfo.authors[0]?:"";
                val desc = bookList!!.items[position].volumeInfo.description?: "Pas de description"
                holder.desc.text = if(desc.length > 200) desc.substring(0,200) + " ..." else desc
                holder.publishedDate.text = bookList!!.items[position].volumeInfo.publishedDate?: "";
                holder.price.text = (bookList!!.items[position].saleInfo.retailPrice?.amount?:"") + " " + bookList!!.items[position].saleInfo.retailPrice?.currencyCode?:"";
                Glide.with(context)
                    .asBitmap()
                    .load(bookList!!.items[position].volumeInfo.imageLinks.thumbnail.replace("http","https"))
                    .into(holder.cover)
            }
        }
    }

    override fun getItemCount(): Int {
        return bookList?.items?.count() ?: 0
    }
}