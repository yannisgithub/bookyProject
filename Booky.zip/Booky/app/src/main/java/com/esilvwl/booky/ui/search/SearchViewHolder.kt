package com.esilvwl.booky.ui.search

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.viewholder_search.view.*

class SearchViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){

    val cover  = itemView.cover
    val title = itemView.title
    val author = itemView.author
    val desc = itemView.desc
    val price = itemView.price
    val publishedDate = itemView.publishedDate
}