package com.esilvwl.booky.ui.account

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.esilvwl.booky.R
import com.esilvwl.booky.api.Api
import kotlinx.android.synthetic.main.fragment_account.*

class AccountFragment : Fragment() {

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_account, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val compte = context?.getSharedPreferences("compte", Context.MODE_PRIVATE)!!.all

        if(!compte.isEmpty())
        {
            pseudo.setText(compte["pseudo"].toString())
            email.setText(compte["email"].toString())
            password.setText(compte["password"].toString())
            confirmPassword.setText(compte["password"].toString())
            newsletters_checkbox.isChecked = compte["newsletters"] as Boolean
        }

        validate_updates.setOnClickListener {
            val compte = context?.getSharedPreferences("compte", Context.MODE_PRIVATE)!!

            compte.edit()
                .putString("pseudo", pseudo.text.toString())
                .putString("email", email.text.toString())
                .putString("password", password.text.toString())
                .putBoolean("newsletters", newsletters_checkbox.isChecked)
                .apply()
        }

    }
}
