package com.esilvwl.booky.ui.search

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.SearchView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.esilvwl.booky.R
import com.esilvwl.booky.api.Api
import com.esilvwl.booky.api.BookList
import kotlinx.android.synthetic.main.fragment_search.*

class SearchFragment : Fragment() {
    val api: Api = Api()
    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_search, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerview!!.adapter = Adapter(this.context!!, null)
        recyclerview!!.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        search_bar.isIconified = false

        //search_bar.isIconifiedByDefault = false
        search_bar.setOnQueryTextListener(object: SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {

                api.searchBooks(search_bar.query.toString()) { bookList ->
                    (recyclerview!!.adapter as Adapter).bookList = bookList
                    recyclerview!!.adapter!!.notifyDataSetChanged()
                }
                search_bar.clearFocus()
                return true
            }
            override fun onQueryTextChange(newText: String?): Boolean {
                return false
            }
        })
    }
}
