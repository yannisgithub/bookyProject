package com.esilvwl.booky.api

import android.util.Log
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class Api() {
    val apiUrl = "https://www.googleapis.com/books/v1/"

    val _retrofit = Retrofit.Builder()
        .baseUrl(apiUrl)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val apiCalls: ApiCalls = _retrofit.create(ApiCalls::class.java)

    fun searchBooks(title: String, callback: (BookList) -> Unit) {

        apiCalls.searchBook(title).enqueue(object : Callback<BookList> {

            override fun onResponse(call: Call<BookList>, response: Response<BookList>) {
                if (response.isSuccessful) {
                    callback(response.body()!!)
                }
            }
            override fun onFailure(call: Call<BookList>, t: Throwable) {
            }
        })
    }
}