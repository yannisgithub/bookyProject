package com.esilvwl.booky.api

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query


interface ApiCalls {

    @GET("volumes?")
    fun searchBook(@Query("q") title: String): Call<BookList>;
}